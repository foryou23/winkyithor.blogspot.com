<?php declare( strict_types = 1 ); ?>
<?php
/**
 * Title: post-meta
 * Slug: feature/post-meta
 * Categories: hidden
 * Inserter: no
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"flex"}} -->
<div class="wp-block-group"><!-- wp:post-time-to-read /-->

<!-- wp:paragraph -->
<p><?php echo __('·', 'feature');?></p>
<!-- /wp:paragraph -->

<!-- wp:post-date {"isLink":true} /-->

<!-- wp:paragraph -->
<p><?php echo __('·', 'feature');?></p>
<!-- /wp:paragraph -->

<!-- wp:post-terms {"term":"category"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group -->